print "Enter your first name: "
first_name = gets.chomp

print "Enter your last name: "
last_name = gets.chomp

full_name = "#{last_name} #{first_name}"
puts "Your name in reverse order is: #{full_name}"


# sudo apt install ruby-full
#cd Desktop
#ruby reverse.rb